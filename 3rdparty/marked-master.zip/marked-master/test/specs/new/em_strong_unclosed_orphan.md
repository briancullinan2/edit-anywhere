**a*b*c
