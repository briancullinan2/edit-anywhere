export default {
  select_lib: 'Select an image library',
  show_list: 'Show library list',
  import_single: 'Import single',
  import_multi: 'Import multiple',
  open: 'Open as new document',
  buttons: [
    {
      title: 'Biblioteca de Imagens'
    }
  ],
  imgLibs_0_name: 'Demo library (local)',
  imgLibs_0_description: 'Demonstration library for SVG-edit on this server',
  imgLibs_1_name: 'IAN Symbol Libraries',
  imgLibs_1_description: 'Free library of illustrations'
}
