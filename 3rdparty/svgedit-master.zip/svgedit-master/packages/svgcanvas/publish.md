see docs/ReleaseInstructions.md
